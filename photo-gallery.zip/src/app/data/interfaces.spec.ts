import { Interfaces } from './interfaces';

describe('Interfaces', () => {
  it('should create an instance', () => {
    expect(new Interfaces()).toBeTruthy();
  });
});
